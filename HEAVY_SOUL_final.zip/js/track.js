// ============================================================
// IMPORTANT: paste your deployed Google Apps Script Web App URL below.
// It should end in /exec — see setup instructions provided separately.
// ============================================================
const APPS_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbwf-ATXC-vcn50Wb0rSAEyTKxQ5XABr9ADETA3OFzoIdFFIkR82e1pEPHy9wnSF-CtoFA/exec";

const STATUS_STEPS = ["Confirmed", "Packed", "Shipped", "Out for Delivery", "Delivered"];

const form = document.getElementById("trackForm");
const input = document.getElementById("orderIdInput");
const resultBox = document.getElementById("trackResult");

// Pre-fill and auto-search if arriving from success.html?order=HS-...
const urlOrder = new URLSearchParams(window.location.search).get("order");
if (urlOrder) {
  input.value = urlOrder;
  lookupOrder(urlOrder);
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const id = input.value.trim();
  if (!id) return;
  lookupOrder(id);
});

async function lookupOrder(orderId) {
  resultBox.innerHTML = `<p class="track-msg">Checking order status…</p>`;

  if (!APPS_SCRIPT_URL || APPS_SCRIPT_URL.includes("PASTE_YOUR")) {
    resultBox.innerHTML = `<p class="track-msg error">Tracking isn't connected yet. Please contact us on WhatsApp with your Order ID.</p>`;
    return;
  }

  try {
    const res = await fetch(`${APPS_SCRIPT_URL}?orderId=${encodeURIComponent(orderId)}`);
    const data = await res.json();

    if (!data.found) {
      resultBox.innerHTML = `<p class="track-msg error">No order found with ID "${orderId}". Please double-check, or contact us on WhatsApp.</p>`;
      return;
    }

    renderStatus(data);
  } catch (err) {
    resultBox.innerHTML = `<p class="track-msg error">Couldn't fetch tracking info right now. Please try again in a bit, or contact us on WhatsApp.</p>`;
  }
}

function renderStatus(data) {
  const currentIndex = STATUS_STEPS.findIndex(
    s => s.toLowerCase() === String(data.status || "").toLowerCase()
  );

  const stepsHtml = STATUS_STEPS.map((step, i) => {
    const done = currentIndex >= 0 && i <= currentIndex;
    const isCurrent = i === currentIndex;
    return `
      <div class="track-step ${done ? "done" : ""} ${isCurrent ? "current" : ""}">
        <span class="dot">${done ? "✓" : ""}</span>
        <span class="label">${step}</span>
      </div>
    `;
  }).join("");

  const hasCustomerInfo = data.customerName || data.phone || data.address;
  const customerHtml = hasCustomerInfo ? `
    <div class="track-customer">
      ${data.customerName ? `<p><b>Name:</b> ${data.customerName}</p>` : ""}
      ${data.phone ? `<p><b>Phone:</b> ${data.phone}</p>` : ""}
      ${data.address ? `<p><b>Address:</b> ${data.address}</p>` : ""}
    </div>
  ` : "";

  resultBox.innerHTML = `
    <div class="track-card">
      <div class="track-live-badge"><span class="track-live-dot"></span> Live Status</div>
      <p class="track-order-id">Order ID: <b style="color:var(--orange)">${data.orderId}</b></p>
      ${customerHtml}
      <div class="track-timeline">${stepsHtml}</div>
      ${data.trackingLink ? `<a href="${data.trackingLink}" target="_blank" rel="noopener" class="hero-btn track-link-btn">View Courier Tracking</a>` : ""}
    </div>
  `;
}
