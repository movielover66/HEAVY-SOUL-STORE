// Single source of truth for all products on the site.
// orderType: "collection" -> ready-made stock item, COD advance = ₹150 per unit (qty)
// orderType: "custom"     -> customized/DTF-on-request item, COD advance = 50% of item price
const products = [
  {
    id: 1,
    name: "KTM Ready To Race",
    category: "Bike",
    price: 399,
    badge: "New",
    orderType: "collection",
    image: "assets/products/ktm.svg",
    images: ["assets/products/ktm.svg"],
    description: "Premium oversized T-shirt with DTF print. 240 GSM heavyweight cotton.",
    sizes: ["S", "M", "L", "XL", "XXL"]
  },
  {
    id: 2,
    name: "Honda CB200X",
    category: "Bike",
    price: 399,
    badge: "Hot",
    orderType: "collection",
    image: "assets/products/honda.svg",
    images: ["assets/products/honda.svg"],
    description: "Premium oversized T-shirt with DTF print. 240 GSM heavyweight cotton.",
    sizes: ["S", "M", "L", "XL", "XXL"]
  },
  {
    id: 3,
    name: "MAX-Z",
    category: "Street",
    price: 399,
    badge: "Sale",
    orderType: "collection",
    image: "assets/products/maxz.svg",
    images: ["assets/products/maxz.svg"],
    description: "Premium oversized T-shirt with DTF print. 240 GSM heavyweight cotton.",
    sizes: ["S", "M", "L", "XL", "XXL"]
  },
  {
    id: 4,
    name: "Heavy Soul Signature",
    category: "Street",
    price: 399,
    badge: "Best Seller",
    orderType: "collection",
    image: "assets/products/heavy1.svg",
    images: ["assets/products/heavy1.svg"],
    description: "Premium oversized T-shirt with DTF print. 240 GSM heavyweight cotton.",
    sizes: ["S", "M", "L", "XL", "XXL"]
  },
  {
    id: 5,
    name: "Custom Design Tee",
    category: "Custom",
    price: 599,
    badge: "Custom",
    orderType: "custom",
    image: "assets/products/heavy1.svg",
    images: ["assets/products/heavy1.svg"],
    description: "Send us your own design/photo — we print it on a premium oversized tee. COD requires 50% advance.",
    sizes: ["S", "M", "L", "XL", "XXL"]
  }
];
