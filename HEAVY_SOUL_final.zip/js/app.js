// Homepage-only logic.

function renderCard(product) {
  return `
    <div class="card">
      ${product.badge ? `<span class="badge-chip">${product.badge}</span>` : ""}
      <a href="product.html?id=${product.id}">
        <img src="${product.image}" alt="${product.name}">
      </a>
      <div class="card-content">
        <div class="card-title">${product.name}</div>
        <div class="price">₹${product.price}</div>
        <a href="product.html?id=${product.id}" class="buy-btn">View Details</a>
      </div>
    </div>
  `;
}

const featuredContainer = document.getElementById("featuredProducts");
if (featuredContainer) {
  featuredContainer.innerHTML = products.map(renderCard).join("");
}

const bestSellerContainer = document.getElementById("bestSellerProducts");
if (bestSellerContainer) {
  const bestSellers = products.filter(p => p.badge === "Best Seller" || p.badge === "Hot");
  bestSellerContainer.innerHTML = (bestSellers.length ? bestSellers : products).map(renderCard).join("");
}

// Hero banner slider
const slides = document.querySelectorAll(".slide");
let current = 0;
if (slides.length > 1) {
  setInterval(() => {
    slides[current].classList.remove("active");
    current = (current + 1) % slides.length;
    slides[current].classList.add("active");
  }, 4000);
}

// Newsletter (front-end only placeholder)
const newsletterBtn = document.querySelector(".newsletter-box button");
if (newsletterBtn) {
  newsletterBtn.onclick = () => {
    const input = document.querySelector(".newsletter-box input");
    if (input && input.value.trim()) {
      alert("Thanks for subscribing!");
      input.value = "";
    } else {
      alert("Please enter your email.");
    }
  };
}
