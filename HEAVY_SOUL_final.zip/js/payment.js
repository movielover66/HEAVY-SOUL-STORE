// ---- Config ----
const COD_FLAT_ADVANCE = 150;       // flat advance for regular "collection" items on COD
const CUSTOM_ADVANCE_PERCENT = 0.5; // 50% advance for "custom" items on COD
const PAYMENT_WINDOW_MS = 10 * 60 * 1000; // 10 minutes
const APPS_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbwf-ATXC-vcn50Wb0rSAEyTKxQ5XABr9ADETA3OFzoIdFFIkR82e1pEPHy9wnSF-CtoFA/exec";

// ---- Load order ----
const cart = JSON.parse(localStorage.getItem("cart")) || [];
const shippingInfo = JSON.parse(localStorage.getItem("shippingInfo") || "null");

if (cart.length === 0) {
  window.location.href = "shop.html";
}
if (!shippingInfo) {
  window.location.href = "checkout.html";
}

let paymentMethod = "prepaid";

// ---- Render order summary ----
const checkoutItems = document.getElementById("checkoutItems");
let subtotal = 0;
let customTotal = 0;
let collectionQty = 0; // total units (not distinct items) of regular "collection" products

cart.forEach(item => {
  const qty = item.qty || 1;
  const lineTotal = item.price * qty;
  subtotal += lineTotal;

  if (item.orderType === "custom") {
    customTotal += lineTotal;
  } else {
    collectionQty += qty;
  }

  checkoutItems.innerHTML += `
    <div class="checkout-item">
      <img src="${item.image}" alt="${item.name}">
      <div>
        <h3>${item.name}</h3>
        <p>Size : ${item.size || "-"}</p>
        <p>Qty : ${qty}</p>
        <p>₹${lineTotal}${item.orderType === "custom" ? " · Custom" : ""}</p>
      </div>
    </div>
  `;
});

document.getElementById("subtotalVal").innerText = "₹" + subtotal;

// ---- Advance calculation ----
function calcCodAdvance() {
  let advance = 0;
  if (customTotal > 0) advance += Math.round(customTotal * CUSTOM_ADVANCE_PERCENT);
  if (collectionQty > 0) advance += COD_FLAT_ADVANCE * collectionQty; // ₹150 per unit, e.g. qty 2 -> ₹300
  return Math.min(advance, subtotal); // never exceed the order total
}

function renderAmounts() {
  const dueLabel = document.getElementById("dueLabel");
  const dueVal = document.getElementById("dueVal");
  const rowRemaining = document.getElementById("rowRemaining");
  const remainingVal = document.getElementById("remainingVal");

  if (paymentMethod === "prepaid") {
    dueLabel.innerText = "Pay Now";
    dueVal.innerText = "₹" + subtotal;
    rowRemaining.classList.add("hidden");
  } else {
    const advance = calcCodAdvance();
    dueLabel.innerText = "Advance To Pay Now";
    dueVal.innerText = "₹" + advance;
    remainingVal.innerText = "₹" + (subtotal - advance);
    rowRemaining.classList.remove("hidden");
  }
}

function setMethod(method) {
  paymentMethod = method;
  document.getElementById("btnPrepaid").classList.toggle("active", method === "prepaid");
  document.getElementById("btnCod").classList.toggle("active", method === "cod");
  renderAmounts();
}

renderAmounts();

// ---- 10 minute countdown (persists across refresh, tied to this checkout attempt) ----
let deadline = Number(localStorage.getItem("paymentDeadline"));
if (!deadline || deadline < Date.now()) {
  deadline = Date.now() + PAYMENT_WINDOW_MS;
  localStorage.setItem("paymentDeadline", String(deadline));
}

const clock = document.getElementById("clock");
const timerBox = document.getElementById("timerBox");

function cancelOrder() {
  localStorage.removeItem("cart");
  localStorage.removeItem("shippingInfo");
  localStorage.removeItem("paymentDeadline");
  document.getElementById("paymentLeft").parentElement.classList.add("hidden");
  document.getElementById("cancelledView").classList.remove("hidden");
}

const tickInterval = setInterval(() => {
  const remainingMs = deadline - Date.now();

  if (remainingMs <= 0) {
    clearInterval(tickInterval);
    clock.innerText = "00:00";
    cancelOrder();
    return;
  }

  const totalSeconds = Math.floor(remainingMs / 1000);
  const mins = Math.floor(totalSeconds / 60);
  const secs = totalSeconds % 60;
  clock.innerText = `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;

  if (remainingMs <= 2 * 60 * 1000) {
    timerBox.classList.add("danger");
  }
}, 1000);

// ---- UPI copy ----
function copyUPI() {
  navigator.clipboard.writeText(document.getElementById("upi").innerText.trim());
  alert("UPI ID Copied");
}

function sendOrderToSheet(orderId, shippingInfo) {
  if (!APPS_SCRIPT_URL || APPS_SCRIPT_URL.includes("PASTE_YOUR")) return;

  const fullAddress = `${shippingInfo.address}, ${shippingInfo.state} - ${shippingInfo.pin}`;

  fetch(APPS_SCRIPT_URL, {
    method: "POST",
    mode: "no-cors", // Apps Script doesn't send CORS headers back; we don't need to read the response
    headers: { "Content-Type": "text/plain;charset=utf-8" }, // avoids a CORS preflight request
    body: JSON.stringify({
      orderId: orderId,
      customerName: shippingInfo.name,
      phone: shippingInfo.phone,
      address: fullAddress
    })
  }).catch(() => {
    // Silent fail — WhatsApp still has the full order details as a backup.
  });
}

// ---- Order ID ----
function generateOrderId() {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, "0");
  const d = String(now.getDate()).padStart(2, "0");
  const rand = String(Math.floor(Math.random() * 900) + 100); // 3-digit random suffix
  return `HS-${y}${m}${d}-${rand}`;
}

// ---- Submit order ----
function placeOrder() {
  if (deadline - Date.now() <= 0) {
    alert("Payment window has expired. Please place the order again.");
    return;
  }

  const utr = document.getElementById("utr").value.trim();
  if (!utr) {
    alert("Please enter your UPI Transaction ID (UTR) after paying.");
    return;
  }

  const orderId = generateOrderId();
  const amountDue = paymentMethod === "prepaid" ? subtotal : calcCodAdvance();
  const remaining = subtotal - amountDue;

  let orderLines = "";
  cart.forEach(item => {
    const qty = item.qty || 1;
    orderLines += `• ${item.name}\nSize: ${item.size || "-"}\nQty: ${qty}\nPrice: ₹${item.price * qty}${item.orderType === "custom" ? " (Custom)" : ""}\n\n`;
  });

  const message = `🛒 *NEW ORDER - HEAVY SOUL*

Order ID: ${orderId}

Name: ${shippingInfo.name}
Phone: ${shippingInfo.phone}
Email: ${shippingInfo.email || "-"}

Address:
${shippingInfo.address}

State: ${shippingInfo.state}
PIN: ${shippingInfo.pin}

--------------------
${orderLines}
Order Total: ₹${subtotal}
Payment Method: ${paymentMethod === "prepaid" ? "Prepaid (Full Payment)" : "COD (Advance Paid)"}
Amount Paid Now: ₹${amountDue}${paymentMethod === "cod" ? `\nRemaining (Pay on Delivery): ₹${remaining}` : ""}

UTR:
${utr}

Please verify payment and confirm the order.`;

  // ---- Auto-add this order to the Google Sheet (no manual typing needed) ----
  sendOrderToSheet(orderId, shippingInfo);

  window.open(`https://wa.me/919339909978?text=${encodeURIComponent(message)}`, "_blank");

  clearInterval(tickInterval);
  localStorage.removeItem("cart");
  localStorage.removeItem("shippingInfo");
  localStorage.removeItem("paymentDeadline");

  alert("Order submitted successfully.");
  window.location.href = `success.html?order=${encodeURIComponent(orderId)}`;
}
