const params = new URLSearchParams(window.location.search);
const id = Number(params.get("id"));
const product = products.find(p => p.id === id);

let selectedSize = "";

if (product) {
  document.querySelector(".info h1").textContent = product.name;
  document.querySelector(".price").textContent = "₹" + product.price;
  document.querySelector(".desc").textContent = product.description;

  const mainImage = document.getElementById("mainImage");
  mainImage.src = product.images[0];

  const gallery = document.querySelector(".gallery");
  product.images.forEach(img => {
    const image = document.createElement("img");
    image.src = img;
    image.onclick = () => { mainImage.src = img; };
    gallery.appendChild(image);
  });

  const sizeBox = document.querySelector(".sizes");
  product.sizes.forEach(size => {
    const div = document.createElement("div");
    div.className = "size";
    div.innerText = size;
    div.onclick = () => {
      document.querySelectorAll(".size").forEach(s => s.classList.remove("active"));
      div.classList.add("active");
      selectedSize = size;
    };
    sizeBox.appendChild(div);
  });

  document.querySelector(".cart").onclick = () => {
    if (selectedSize === "") {
      alert("Select Size");
      return;
    }
    addToCart(product, selectedSize);
  };

  document.querySelector(".buy").onclick = () => {
    if (selectedSize === "") {
      alert("Select Size");
      return;
    }
    addToCart(product, selectedSize);
    window.location.href = "checkout.html";
  };
} else {
  document.querySelector(".product-page").innerHTML = `<p style="padding:40px">Product not found. <a href="shop.html" style="color:#ff6600">Back to shop</a></p>`;
}

function openSizeGuide() {
  document.getElementById("sizeGuideModal").classList.remove("hidden");
}
function closeSizeGuide() {
  document.getElementById("sizeGuideModal").classList.add("hidden");
}
