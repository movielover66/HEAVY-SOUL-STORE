// Step 1: Shipping details. Cart is read fresh from localStorage (no shared global with cart.js).
const orderCart = JSON.parse(localStorage.getItem("cart")) || [];

const checkoutItems = document.getElementById("checkoutItems");
const totalPriceEl = document.getElementById("totalPrice");

let total = 0;

if (orderCart.length === 0) {
  checkoutItems.innerHTML = `<p>Your cart is empty. <a href="shop.html" style="color:#f5940a">Go shopping</a></p>`;
} else {
  orderCart.forEach(item => {
    const qty = item.qty || 1;
    total += item.price * qty;

    checkoutItems.innerHTML += `
      <div class="checkout-item">
        <img src="${item.image}" alt="${item.name}">
        <div>
          <h3>${item.name}</h3>
          <p>Size : ${item.size || "-"}</p>
          <p>Qty : ${qty}</p>
          <p>₹${item.price * qty}</p>
        </div>
      </div>
    `;
  });
}

totalPriceEl.innerText = "₹" + total;

function goToPayment() {
  if (orderCart.length === 0) {
    alert("Your cart is empty.");
    return;
  }

  const name = document.getElementById("name").value.trim();
  const phone = document.getElementById("phone").value.trim();
  const email = document.getElementById("email").value.trim();
  const address = document.getElementById("address").value.trim();
  const state = document.getElementById("state").value.trim();
  const pin = document.getElementById("pin").value.trim();

  if (!name || !phone || !address || !state || !pin) {
    alert("Please fill all required details.");
    return;
  }

  const shippingInfo = { name, phone, email, address, state, pin };
  localStorage.setItem("shippingInfo", JSON.stringify(shippingInfo));

  // Clear any leftover payment session from a previous, abandoned checkout attempt.
  localStorage.removeItem("paymentDeadline");
  localStorage.removeItem("paymentMethod");

  window.location.href = "payment.html";
}
