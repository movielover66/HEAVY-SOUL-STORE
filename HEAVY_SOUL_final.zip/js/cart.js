// Cart storage + rendering. Loaded on every page (via cart.html, checkout uses its own copy of the array).
let cart = JSON.parse(localStorage.getItem("cart")) || [];

function saveCart() {
  localStorage.setItem("cart", JSON.stringify(cart));
}

function addToCart(product, size) {
  const existing = cart.find(item => item.id === product.id && item.size === size);
  if (existing) {
    existing.qty += 1;
  } else {
    cart.push({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      orderType: product.orderType || "collection",
      size: size || "-",
      qty: 1
    });
  }
  saveCart();
  alert("Added to Cart");
}

function loadCart() {
  const cartContainer = document.getElementById("cartItems");
  if (!cartContainer) return;

  cartContainer.innerHTML = "";

  if (cart.length === 0) {
    cartContainer.innerHTML = `<div class="empty">Your Cart is Empty</div>`;
    document.querySelector(".total").innerHTML = "Total : ₹0";
    return;
  }

  let total = 0;

  cart.forEach(item => {
    const qty = item.qty || 1;
    total += item.price * qty;

    cartContainer.innerHTML += `
      <div class="cart-item">
        <img src="${item.image}" alt="${item.name}">
        <div class="cart-details">
          <h2>${item.name}</h2>
          <p>Size : ${item.size || "-"}</p>
          <div class="qty-stepper">
            <button onclick="changeQty(${item.id}, '${item.size}', -1)" aria-label="Decrease quantity">−</button>
            <span class="qty-num">${qty}</span>
            <button onclick="changeQty(${item.id}, '${item.size}', 1)" aria-label="Increase quantity">+</button>
          </div>
          <div class="cart-price">₹${item.price * qty}</div>
        </div>
        <button class="remove-btn" onclick="removeItem(${item.id}, '${item.size}')">Remove</button>
      </div>
    `;
  });

  document.querySelector(".total").innerHTML = `Total : ₹${total}`;
}

function changeQty(id, size, delta) {
  const item = cart.find(i => i.id === id && i.size === size);
  if (!item) return;
  item.qty = (item.qty || 1) + delta;
  if (item.qty < 1) {
    cart = cart.filter(i => !(i.id === id && i.size === size));
  }
  saveCart();
  loadCart();
}

function removeItem(id, size) {
  cart = cart.filter(item => !(item.id === id && item.size === size));
  saveCart();
  loadCart();
}

loadCart();
